# bot/cogs/tasks/survival_task.py
import nextcord
from nextcord.ext import commands, tasks
import logging

from core.icons import ICON_WARNING, ICON_ECOIN

logger = logging.getLogger(__name__)

# Các hằng số cho sự suy giảm
HUNGER_DECAY_PER_HOUR = 2
ENERGY_DECAY_PER_HOUR = 3
HEALTH_DECAY_WHEN_STARVING = 5
FAINT_PENALTY_PERCENTAGE = 0.10 # 10%

class SurvivalTaskCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.stat_decay_loop.start()
        logger.info("SurvivalTaskCog (v2 - Refactored) initialized and stat decay task started.")

    def cog_unload(self):
        self.stat_decay_loop.cancel()
        logger.info("SurvivalTaskCog unloaded and stat decay task cancelled.")

    @tasks.loop(hours=1)
    async def stat_decay_loop(self):
        """
        Tác vụ chạy nền để giảm chỉ số sinh tồn của tất cả người chơi.
        """
        logger.info("Survival Decay Task: Running...")
        
        try:
            # Sử dụng cache
            economy_data = self.bot.economy_data
            users_data = economy_data.get("users", {})

            # Lặp qua tất cả người chơi và tất cả các server họ đã tham gia
            for user_id, global_profile in users_data.items():
                for guild_id, local_data in global_profile.get("server_data", {}).items():
                    
                    stats = local_data.get("survival_stats")
                    if not stats:
                        continue

                    # --- Logic suy giảm ---
                    stats["hunger"] = max(0, stats["hunger"] - HUNGER_DECAY_PER_HOUR)
                    stats["energy"] = max(0, stats["energy"] - ENERGY_DECAY_PER_HOUR)

                    # --- Hậu quả khi đói ---
                    if stats["hunger"] == 0:
                        stats["health"] = max(0, stats["health"] - HEALTH_DECAY_WHEN_STARVING)

                        # --- Hậu quả khi ngất xỉu ---
                        if stats["health"] == 0:
                            earned_balance = local_data["local_balance"]["earned"]
                            penalty = int(earned_balance * FAINT_PENALTY_PERCENTAGE)
                            local_data["local_balance"]["earned"] -= penalty
                            
                            stats["health"] = 50
                            stats["hunger"] = 50
                            stats["energy"] = 50

                            try:
                                user = await self.bot.fetch_user(int(user_id))
                                guild = self.bot.get_guild(int(guild_id))
                                guild_name = guild.name if guild else "không xác định"
                                
                                await user.send(
                                    f"{ICON_WARNING} Bạn đã ngất xỉu vì kiệt sức tại server **{guild_name}**!\n"
                                    f"Bạn đã bị trừ **{penalty:,}** {ICON_ECOIN} và các chỉ số đã được hồi phục một phần."
                                )
                                logger.warning(f"User {user_id} fainted in guild {guild_id}, fined {penalty}.")
                            except Exception as dm_error:
                                logger.error(f"Could not send faint DM to {user_id}: {dm_error}")

            # Không cần save, autosave task sẽ lo việc này
            logger.info("Survival Decay Task: Finished.")

        except Exception as e:
            logger.error(f"Error in Survival Decay Task: {e}", exc_info=True)

    @stat_decay_loop.before_loop
    async def before_decay_task(self):
        await self.bot.wait_until_ready()

def setup(bot: commands.Bot):
    bot.add_cog(SurvivalTaskCog(bot))
